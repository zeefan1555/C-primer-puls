
	char ruler[Len];